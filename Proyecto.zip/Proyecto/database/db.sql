use ingweb;

create table register (
	id int(6) unsigned auto_increment primary key,
    cognomen varchar(100) not null,
    surname varchar(100) not null,
    email varchar(50) not null,
    userlog varchar(100) not null,
    psswd varchar(10) not null
);


alter table register 
add phone varchar(10) not null;

