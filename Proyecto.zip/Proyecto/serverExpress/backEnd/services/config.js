module.exports = {
    db:{
        host: 'localhost',
        user: 'root',
        password: 'P4chec0',
        database: 'ingweb',
    }
}