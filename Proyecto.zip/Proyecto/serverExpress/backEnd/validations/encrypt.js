const bcrypt = require('bcryptjs');
const encrypt = {};

//Password encrypt
encrypt.psswdEncrypt = async (psswd) =>{
    const salt = await bcrypt.genSalt(10); //generamos el patron
    const hash = bcrypt.hash(psswd, salt); //Se cifra la psswd
    return hash;
};

encrypt.matchPsswd = async (psswd, savedPsswd) => {
    try {
        return await bcrypt.compare(psswd, savedPsswd);
    } catch(e){
        console.log(e);
    }
};

module.exports = encrypt;