const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;

const pool = require('../connection');
const encrypt = require('./encrypt');
const { validationResult } = require('express-validator');

passport.use('local.login', new LocalStrategy({
    usernameField: 'userlog',
    passwordField: 'psswd',
    passReqToCallback: true
}, async (req, userlog, psswd, done) =>{
     pool.query('SELECT * FROM register WHERE userlog = ?', [userlog],  async (err, data, fields) => {
        if(err){
            console.log('Fail to obtain data: '+ err.stack);
            return;
        }
        const userPsswd = data.map(data => data.psswd);
        if(data.length > 0){
            const user = data[0];
            const validPsswd = await encrypt.matchPsswd(psswd, userPsswd.toString());
            if(validPsswd){
                done(null, user);
            } else {
                done(null, false);
            }
        } else {
            return done(null, false);
        }
        
    });
}));

passport.use('local.register', new LocalStrategy({
    usernameField: 'userlog',
    passwordField: 'psswd',
    passReqToCallback: true
}, async (req, userlog, psswd, done) =>{
    const id = 0;
    const cognomen = req.body.cognomen;
    const surname = req.body.surname;
    const email = req.body.email;
    const phone = req.body.phone;

    const newUser = {
        id,
        cognomen,
        surname,
        email,
        userlog,
        psswd,
        phone
    };
    newUser.psswd = await encrypt.psswdEncrypt(psswd);
    const result = await pool.query("INSERT INTO register SET ?", [newUser], (err, results, fields) => {
        if (err){
            console.log('Fail to save data: '+ err.stack);
            return;
        }
        console.log('SAVED DATA');
        //console.log(result);
        const idQuery = pool.query("SELECT id FROM register WHERE userlog = ?", [newUser.userlog], function(err, data, fields){
            if(err){
                console.log('Fail to obtain data: '+ err.stack);
                return;
            } 
            //console.log(data);
            const ids = data.map(data => data.id);
            //console.log(ids);
            newUser.id = ids;
            //console.log(newUser.id);
            //console.log(newUser);
            return done(null, newUser);
        });
    });
}));

passport.serializeUser((user, done) => {
    //console.log(user.id);
    done(null, user.id);
});

passport.deserializeUser(async (id, done) =>{
    //console.log(id);
    const rows = await pool.query('SELECT * FROM register WHERE id = ?', [id], function(err, data, fields){
        if(err){
            console.log('Fail to obtain data: '+ err.stack);
            return;
        }
        //console.log(rows);
        //console.log(data);
        //const row = data.map(data => data.userlog);
        done(null, data[0]);
    });
});