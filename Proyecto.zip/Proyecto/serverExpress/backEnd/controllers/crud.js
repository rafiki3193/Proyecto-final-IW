const pool = require("../connection");

const controller = {};

controller.list = (req, res) => {
    pool.query('SELECT * FROM customer WHERE user_id = ?', [req.user.id], (err, customers) => {
        if (err) {
            res.json(err);
        }
        console.log(customers);
        res.render('users/links', {
            data: customers
        });
    });
};

controller.save = (req, res) => {
  const {name,address,description,}=req.body;
  const data = {
        name,
        address,
        description,
        user_id: req.user.id
    };
    console.log(req.body);
    const query = pool.query('INSERT INTO customer set ?', [data] ,(err, customer) => {
        console.log(customer);
        res.redirect('/users/profile');
    })
};

controller.edit = (req, res) => {
    const { id } = req.params;
    pool.query("SELECT * FROM customer WHERE id = ?", [id], (err, rows) => {
        res.render('users/linksEdit', {
        data: rows[0]
      });
    });
};

controller.update = (req, res) => {
    const { id } = req.params;
    const newCustomer = req.body;
    pool.query('UPDATE customer set ? where id = ?', [newCustomer, id], (err, rows) => {
        res.redirect('/users/profile');
    });
};

controller.delete = (req, res) => {
    const { id } = req.params;
    pool.query('DELETE FROM customer WHERE id = ?', [id], (err, rows) => {
        res.redirect('/users/profile');
    });
}     

module.exports = controller;