const express = require('express');
const router = express.Router();
const passport = require('passport');
const {isLoggedIn, isNotLoggedIn} = require('../validations/auth');

const pool = require('../connection');
const crud = require('../controllers/crud');

router.get('/login', isNotLoggedIn, (req, res)=>{
    res.render('users/login');
});

router.post('/login', isNotLoggedIn, (req, res, next)=>{
    passport.authenticate('local.login',{ 
        successRedirect: 'profile',
        failureRedirect: 'login',
        failureFlash: true
    })(req, res, next);
});

router.get('/recoverPsswd', (req, res)=>{
    res.render('users/recoverPsswd');
});

router.get('/register', isNotLoggedIn, (req, res)=>{
    console.log(__dirname);
    res.render('users/register');
});

router.post('/register', isNotLoggedIn, passport.authenticate('local.register', {
    successRedirect: 'login',
    failureRedirect: 'register',
    failureFlash: true
}));

// router.get('/profile', (req, res)=>{
//     // res.send('Your Profile');
//     res.render('users/links');
// });

router.get('/profile', isLoggedIn, crud.list);
router.post('/profile/add',isLoggedIn, crud.save);
router.get('/profile/update/:id', isLoggedIn, crud.edit);
router.post('/profile/update/:id', isLoggedIn, crud.update, (req, res)=>{
    console.log(__dirname);
});
router.get('/profile/delete/:id', isLoggedIn, crud.delete);

router.get('/logout', (req, res) =>{
    req.logOut(function(err){
        if(err){
            console.log(err);
            return res.status(500).send('Log Out error');
        }
        res.redirect('login');
    });
});

module.exports = router;