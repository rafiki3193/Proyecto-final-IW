const path = require('path');
const createError = require('http-errors');
const express = require('express');
const session = require('express-session');
const validator = require('express-validator');
const passport = require('passport');
const MySQLStore = require('express-mysql-session')(session);
const flash = require('connect-flash');
const { db } = require('./services/config');

const index = require('./routes/index');
const users = require('./routes/users');

//Initializations
const app = express();
require('./validations/passport');
const PORT = process.env.PORT || 3000;

console.log(__dirname);
app.use(express.static(path.join(__dirname, '../frontEnd/public')));
app.use(express.urlencoded({extended: false}))
app.use(session({
    secret: 'ingwebproject',
    resave: false,
    saveUninitialized: false,
    store: new MySQLStore(db)
}));
app.use(flash());
app.use(passport.initialize());
app.use(passport.session());

app.use((req, res, next) =>{
    app.locals.success = req.flash('success');
    next();
});


// view engine setup
app.set('views', path.join(__dirname, '../frontEnd/views'));
app.set('view engine', 'ejs');

//settle routes
app.use('/', index);
app.use('/users', users);

// localhost:3000
app.listen(PORT, ()=>{
    console.log(`Aplicación ejecutandose en el localhost puerto ${PORT}`);
})

module.exports = app;